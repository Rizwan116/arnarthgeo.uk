<?php include('header.php');?>
<section class="page-title" style="background-image:url(images/background/featured-2-bg.jpg);">
        <div class="auto-container">
            <h1>Quality Assurance</h1>
        </div>
        
        <!--page-info-->
        <div class="page-info">
        	<div class="auto-container">
            	<div class="row clearfix">
            
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="bread-crumb clearfix">
                            <li><a href="index.php">Home</a></li>
                            <li class="active">Quality Assurance</li>
                        </ul>
                    </div>
                    
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="social-nav clearfix">
                            <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                           
                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                           
                        </ul>
                    </div>
                
                </div>
            </div>
        </div>
        
    </section>
	<br></br>
	<section class="services-style-three">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<div class="column col-md-12 col-sm-12 col-xs-12">
            	    <ul class="list-style-one">
                                    <li><span class="fa fa-check-square-o"></span> <b>Tape Plant :</b> At tape plant level, every lot of the produced tapes is checked for its denier & strength.</li>
                                    <li><span class="fa fa-check-square-o"></span> <b>Beta Gauge :</b> We also have the Beta gauge machines which continuously checks the size and the denier of the tape.</li>
                                    <li><span class="fa fa-check-square-o"></span> <b>Fabric Checking :</b> Fabric produced by every loom is checked for right weaving, width, strength and finish.</li>
                               <li><span class="fa fa-check-square-o"></span> <b>In Process Checking :</b>Checking of all the parameters required at the semi-finished & finished stage which mainly includes, cutting & stitching</li>
                                    <li><span class="fa fa-check-square-o"></span> <b>In House Printing :</b> Printing is checked for print quality, adherence of ink, and stitching is monitored with reference to the specifications.</li>
                                    <li><span class="fa fa-check-square-o"></span> <b>Tensile Test :</b> Tensile and breaking strength of all the lots is checked on Tensile Tester.</li>
                                     <li><span class="fa fa-check-square-o"></span> <b>Various Necessary Tests :</b> Load Test, Length & Width Test, Gusset Test, Valve Test, etc. are also carried out.</li>
                                      <li><span class="fa fa-check-square-o"></span> <b>Complete Inspection :</b> Full detailed inspection is carried out at each and every level to ensure the bags are made with the tolerance allowance.</li>
                               
                                </ul>
            	    
            	    </div>
            
				
				
				
				
            </div>
        </div>
    </section>
	
<?php include('footer.php');?>	