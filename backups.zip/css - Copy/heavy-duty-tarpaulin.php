<?php include('header.php');?>
<section class="page-title" style="background-image:url(images/background/featured-2-bg.jpg);">
        <div class="auto-container">
            <h1>Heavy Duty Tarpaulin</h1>
        </div>
        
        <!--page-info-->
        <div class="page-info">
        	<div class="auto-container">
            	<div class="row clearfix">
            
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="bread-crumb clearfix">
                            <li><a href="index.php">Home</a></li>
                            <li class="active">Heavy Duty Tarpaulin</li>
                        </ul>
                    </div>
                    
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="social-nav clearfix">
                            <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                           
                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                           
                        </ul>
                    </div>
                
                </div>
            </div>
        </div>
        
    </section>
	
	
	
<?php include('footer.php');?>	