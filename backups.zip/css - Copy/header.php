<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>ARNATH GEOTEXTILE</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/revolution-slider.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<!--Favicon-->
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link href="css/responsive.css" rel="stylesheet">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>
<div class="page-wrapper">
 	
   	
    <!-- Main Header-->
    <header class="main-header header-style-two">
        <!-- Header Top -->
    	<div class="header-top">
        	<div class="auto-container clearfix">
				<!--Top Left-->
				<div class="top-left pull-left">
					<ul class="links-nav clearfix">
						<li><span class="fa fa-support"></span> Welcome to Arnath Geo</li>
						<li><div id="google_translate_element"></div></li>
					</ul>
				</div>
				
				<!--Top Right-->
				<div class="top-right pull-right">
					<ul class="links-nav clearfix">
						<li><span class="fa fa-envelope"></span>mail@arnathgeo.com</li>
						<!--<li><span class="fa fa-phone"></span> +44 7901 351369</li>-->
					</ul>
				</div>
			</div>
        </div>
        <!-- Header Top End -->
        
        <!--Header-Upper-->
        <div class="header-upper">
        	<div class="auto-container">
            	<div class="clearfix">
                	
                	<div class="pull-left logo-outer">
                    	<div class="logo"><a href="index.php"><img src="images/logo.png" alt="Arnath Geotextile" title="Arnath Geotextile"></a></div>
                    </div>
                    
                    <div class="pull-right upper-right clearfix">
                    	
                        <div class="nav-outer clearfix">
                            <!-- Main Menu -->
                            <nav class="main-menu">
                                <div class="navbar-header">
                                    <!-- Toggle Button -->    	
                                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    </button>
                                </div>
                                
                                <div class="navbar-collapse collapse clearfix">
                                    <ul class="navigation clearfix">
                                <li class="current"><a href="index.php">Home</a>
                                    
                                </li>
                                <li><a href="about-us.php">About Us</a></li>
                                <li class="dropdown"><a href="#">Products</a>
                                    <ul>
                                         <!-- <li><a href="industrial-fabric.php">FIBC </a></li> -->
                                       <li><a href="fibc_product.php">FIBC </a></li>
                                        <li><a href="sand-bags.php">PP Woven Sack / Sand Bags</a></li>
                                         <li><a href="tarpulins.php">Pallet Covers / Tarpaulins</a></li>
                                         <li><a href="Stretch_Films.php">Stretch Films</a></li>
                                          
                                        <li><a href="erosion-control-section.php">Erosion Control Section</a></li>
                                        <li><a href="agriculture-fabric.php">Agriculture Fabric</a></li>
                                    
                                       <li><a href="heavy-duty-tarpaulin.php">Heavy Duty Tarpaulin</a></li>
                                       
                                        <li><a href="industrial-fabric.php">Industrial Fabric</a></li>
                                       <li><a href="geo-textiles.php">Geo Textiles</a></li>
                                    </ul>
                                </li>
                       
								<li><a href="infrastructure.php">Infrastructure</a></li>
							    <li><a href="quality-assurance.php">Quality Assurance</a></li>
                               
                                <li><a href="contact-us.php">Contact Us</a></li>
                            </ul>
                                </div>
                            </nav><!-- Main Menu End-->
                            
                            <!--Quote Button-->
                            <div class="btn-outer"><a href="contact-us.php" class="theme-btn quote-btn btn-style-four"><span class="fa fa-mail-reply-all"></span> Get a Quote</a></div>
                            
                        </div>
                        
                    </div>
                    
                </div>
            </div>
        </div>
        
        <!--Sticky Header-->
        <div class="sticky-header">
        	<div class="auto-container clearfix">
            	<!--Logo-->
            	<div class="logo pull-left">
                	<a href="index.php" class="img-responsive"><img src="images/logo.png" alt=" Arnath Geotextile" title=" Arnath Geotextile"></a>
                </div>
                
                <!--Right Col-->
                <div class="right-col pull-right">
                	<!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->    	
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>
                        
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                               <li class="current"><a href="index.php">Home</a>
                                    
                                </li>
                                <li><a href="about-us.php">About Us</a></li>
                                <li class="dropdown"><a href="#">Products</a>
                                    <ul>
                                       <li><a href="fibc_product.php">FIBC </a></li>
                                       <li><a href="sand-bags.php">PP Woven Sack / Sand Bags</a></li>
                                         <li><a href="tarpulins.php">Pallet Covers / Tarpaulins</a></li>
                                          <li><a href="Stretch_Films.php">Stretch Films</a></li>
                                        <li><a href="erosion-control-section.php">Erosion Control Section</a></li>
                                        <li><a href="agriculture-fabric.php">Agriculture Fabric</a></li>
                                      
                                       <li><a href="heavy-duty-tarpaulin.php">Heavy Duty Tarpaulin</a></li>
                                       
                                        <li><a href="industrial-fabric.php">Industrial Fabric</a></li>
                                       <li><a href="geo-textiles.php">Geo Textiles</a></li>
                                    </ul>
                                </li>
								<li><a href="infrastructure.php">Infrastructure</a></li>
								  <li><a href="quality-assurance.php">Quality Assurance</a></li>
                               
                                <li><a href="contact-us.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </nav><!-- Main Menu End-->
                </div>
                
            </div>
        </div>
        <!--End Sticky Header-->
    
    </header>
    <!--End Main Header -->
    