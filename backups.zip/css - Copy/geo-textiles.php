<?php include('header.php');?>
<section class="page-title" style="background-image:url(images/background/featured-2-bg.jpg);">
        <div class="auto-container">
            <h1>Geo Textiles</h1>
        </div>
        
        <!--page-info-->
        <div class="page-info">
        	<div class="auto-container">
            	<div class="row clearfix">
            
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="bread-crumb clearfix">
                            <li><a href="index.php">Home</a></li>
                            <li class="active">Geo Textiles</li>
                        </ul>
                    </div>
                    
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="social-nav clearfix">
                            <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                           
                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                           
                        </ul>
                    </div>
                
                </div>
            </div>
        </div>
        
    </section>
	
	<div class="sidebar-page-container">
        <div class="auto-container">
            <div class="row clearfix">

                <!--Content Side-->
                <div class="content-side col-lg-9 col-md-8 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/geotextile.png" alt=""></figure>
						<div class="sec-title-one"><h2>Geo Textiles</h2></div>

                        <div class="text-block">
                        	<p>A geotextile is considered as any permeable textile material used to increase soil stability, provide erosion control or aid in drainage. More simply put, if it is made of fabric and buried in the ground it is probably a geotextile! Geotextiles are usually made from a synthetic polymer such as polypropylene, polyester, polyethylene and polyamides. Geotextiles can be woven, knitted or non-woven. Varying polymers and manufacturing processes result in an array of geotextiles suitable for a variety of civil construction applications.</p>
<p>ARNATH woven geotextile is a flat textile structure produced by interlacing two or more sets of strands at right angles. There are two types of strands: slit films, which are flat; and monofilaments, which are round. The woven slit-film geotextiles are preferred for applications where high strength properties are needed and filtration requirements are less of any importance. These fabrics reduce localized shear failure in weak conditions under the soil and aid construction over soft subsoils. Woven monofilament geotextiles are preferred for applications where both strength and filtration are a concern, such as shoreline rip rap applications.</p>                           
<p>We can offer the woven geo textiles as per below details, Please also look at some of the specifications for your reference as well. </p>
 <ul class="list-style-one">
                                    <li><span class="fa fa-check-square-o"></span> <b>Standard Width:</b> 12.5′ – 15.0’ – 17.5’</li>
                                    <li><span class="fa fa-check-square-o"></span> <b>Standard Roll Length:</b> 258′- 300’- 309’- 360’- 432′</li>
                                    <li><span class="fa fa-check-square-o"></span> <b>Available Color:</b> Black</li>
                               
                                </ul>

						   </div>

                        
						
                
                        
                    </section>

				</div>
                <!--Content Side-->

				<!--Sidebar-->
                <div class="col-lg-3 col-md-4 col-sm-12 col-xs-12">
                    <aside class="sidebar about-sidebar">

                        <!-- Tabbed Links -->
                        <div class="sidebar-widget tabbed-links">
                            <ul class="tabbed-nav">
                            	 <li><a href="geo-textiles.php">Geo Textiles</a></li>
                                        <li><a href="erosion-control-section.php">Erosion Control Section</a></li>
                                        <li><a href="agriculture-fabric.php">Agriculture Fabric</a></li>
                                        <li><a href="tarpulins.php">Tarpaulins</a></li>
                                        <li><a href="heavy-duty-tarpaulin.php">Heavy Duty Tarpaulin</a></li>
                                        <li><a href="sand-bags.php">Sand Bags</a></li>
                                        <li><a href="industrial-fabric.php">Industrial Fabric</a></li>
                            </ul>

                        </div>

                        <!-- Tabbed Links -->
                        <div class="sidebar-widget download-links">
                            <div class="sec-title-seven"><h2>Download Brochures</h2></div>
                            <ul class="files">
                            	<li><a href="#"><span class="fa fa-file-pdf-o"></span> Download here .PDF</a></li>
                                 </ul>

                        </div>

						<!--quote-widget-->
						<div class="call-to-action-four" style="background-image:url(images/resource/quote-widget.jpg);">
                        	<div class="title">Any Questions related Solutions? Call us</div>
                            
                            <!--<div class="number"><span class="flaticon-phone-receiver"></span> +44 7901 351369</div>-->
                            <a class="theme-btn btn-style-one" href="contact-us.php">GET QUOTES</a>
                        </div>

                    </aside>


                </div>
                <!--Sidebar-->


            </div>
        </div>
    </div>
	
<?php include('footer.php');?>	