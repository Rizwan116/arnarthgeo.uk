<?php include('header.php');?>
<section class="page-title" style="background-image:url(images/background/featured-2-bg.jpg);">
        <div class="auto-container">
            <h1>Infrastructure</h1>
        </div>
        
        <!--page-info-->
        <div class="page-info">
        	<div class="auto-container">
            	<div class="row clearfix">
            
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="bread-crumb clearfix">
                            <li><a href="index.php">Home</a></li>
                            <li class="active">Infrastructure</li>
                        </ul>
                    </div>
                    
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="social-nav clearfix">
                            <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                           
                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                           
                        </ul>
                    </div>
                
                </div>
            </div>
        </div>
        
    </section>
	<section class="industry-section">
    	<div class="auto-container">
        
        	    
        	    <div class="row clearfix">
                        	
                            <div class="col-md-6 col-sm-6 col-xs-12 mb-3">
                            	<div class="sec-title-eight"><h2>TAPE PLANT </h2></div>
                                <div class="text">•	Type & Maker:   Lohia Sterlinger Ltd<br>
•	No. Of Machines:  3 High speed tape extrusion lines<br>
•	Capacity of each Plant:  500 kgs per hr<br>
<br>
</div>
<img src="images/tape.png" />
                                
                             </div>
                        
                        	<div class="col-md-6 col-sm-6 col-xs-12 clearfix mb-3">
                            	<div class="sec-title-eight"><h2>WEAVING LOOMS </h2></div>
                                <div class="text">•	Type of Looms : Circular weaving looms of all kinds<br>
•	Maker  : Lohia Corp Limited<br>
•	No. Of Machines:  80 Nos<br>
•	Capacity of Machines  :1,50,000 meter per day


</div>
<img src="images/weaving.png" />
                                
                             </div>
                             
                             
                      
                        	<div class="col-md-6 col-sm-6 col-xs-12 clearfix mt-3">
                        	           <br></br>
                            	<div class="sec-title-eight"><h2>PRINTING MACHINE</h2></div>
                                <div class="text">•	Roll to roll Printing Machines:- 3 Machines<br>
•	Colors :- up-to 6 colors<br>
•	Printing capacity :- 70,000 meters/day/ machine 



</div>
<img src="images/printing.png" />
                                
                             </div>
                             
                            
                        	<div class="col-md-6 col-sm-6 col-xs-12 clearfix">   <br></br>
                            	<div class="sec-title-eight"><h2>EXTRUSION LAMINATION PLANT</h2></div>
                                <div class="text">•	Maker  :  J.P. Industries Ltd.<br>
•	Capacity / HR :  400 Kgs/hour 
<br><br>
</div>
<img src="images/lamination.png" />
                                
                             </div>
                             
                             
                             
                            </div>
                            
                        </div>
        	    
        	    
        	    
            	

               
            
        </div>
    </div></section>
	
	
<?php include('footer.php');?>	