<?php include('header.php');?>
<section class="page-title" style="background-image:url(images/background/featured-2-bg.jpg);">
   <div class="auto-container">
      <h1>Helicopter FIBC Bulk Bags</h1>
   </div>
   <!--page-info-->
   <div class="page-info">
      <div class="auto-container">
         <div class="row clearfix">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <ul class="bread-crumb clearfix">
                  <li><a href="index.php">Home</a></li>
                  <li class="active">Helicopter FIBC Bulk Bags</li>
               </ul>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
               <ul class="social-nav clearfix">
                  <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                  <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                  <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
               </ul>
            </div>
         </div>
      </div>
   </div>
</section>
<div class="sidebar-page-container">
   <div class="auto-container">
      <div class="row clearfix">
         <!--Content Side-->
         <div class="content-side col-lg-9 col-md-8 col-sm-12 col-xs-12">
            <section class="content-section services-content">
               <figure class="bigger-image"><img src="images/Helicopter FIBC Bulk Bags.pdf-image-000.jpg" alt=""></figure>
               <div class="sec-title-one">
                  <h2>Helicopter FIBC Bulk Bags</h2>
               </div>
               <div class="text-block">
                  <p>From builders bags to fully conductive Type C
                    FIBC’s we have them all. Most of our clients
                    enjoy the option of having their FIBC’s tailored
                    to their particular needs, but in case of that
                    ‘just in time’ delivery we have a large range of
                    finished stock in the UK ready for dispatch.</p>
                    
                    <h4>
                        Extra Options Include:
                    </h4>
                    <ul class="list-style-one">
                        <li><span class="fa fa-check-square-o"></span> Various filling & discharge options</li>
                        <li><span class="fa fa-check-square-o"></span> Coated fabric with sift proof seams</li>
                        <li><span class="fa fa-check-square-o"></span> Type C & D Conductive</li>
                        <li><span class="fa fa-check-square-o"></span> UN Approved</li>
                        <li><span class="fa fa-check-square-o"></span> Inner pre-shaped liners</li>
                        <li><span class="fa fa-check-square-o"></span> Q Baffle bags</li>
                        <li><span class="fa fa-check-square-o"></span> Gambo design</li>
                        <li><span class="fa fa-check-square-o"></span> Asbestos range</li>
                        <li><span class="fa fa-check-square-o"></span> Food grade</li>
                    </ul>
                    
                    <div class="content-side col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <img src="images/Helicopter FIBC Bulk Bags.pdf-image-005.jpg" style="height: 200px">
                    </div>
                    <div class="content-side col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <img src="images/Helicopter FIBC Bulk Bags.pdf-image-001.jpg" style="height: 200px">
                    </div>
                    <div class="content-side col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <img src="images/Helicopter FIBC Bulk Bags.pdf-image-003.jpg" style="height: 200px">
                    </div>
                  <!--<ul class="list-style-one">-->
                  <!--   <li><span class="fa fa-check-square-o"></span> <b>Standard Width:</b> 12.5′ – 15.0’ – 17.5’</li>-->
                  <!--   <li><span class="fa fa-check-square-o"></span> <b>Standard Roll Length:</b> 258′- 300’- 309’- 360’- 432′</li>-->
                  <!--   <li><span class="fa fa-check-square-o"></span> <b>Available Color:</b> Black</li>-->
                  <!--</ul>-->
               </div>
            </section>
         </div>
         <!--Content Side-->
         <!--Sidebar-->
         <div class="col-lg-3 col-md-4 col-sm-12 col-xs-12">
            <aside class="sidebar about-sidebar">
               <!-- Tabbed Links -->
               <div class="sidebar-widget tabbed-links">
                  <ul class="tabbed-nav">
                     <li><a href="geo-textiles.php">Geo Textiles</a></li>
                     <li><a href="erosion-control-section.php">Erosion Control Section</a></li>
                     <li><a href="agriculture-fabric.php">Agriculture Fabric</a></li>
                     <li><a href="tarpulins.php">Tarpaulins</a></li>
                     <li><a href="heavy-duty-tarpaulin.php">Heavy Duty Tarpaulin</a></li>
                     <li><a href="sand-bags.php">Sand Bags</a></li>
                     <li><a href="industrial-fabric.php">Industrial Fabric</a></li>
                  </ul>
               </div>
               <!-- Tabbed Links -->
               <div class="sidebar-widget download-links">
                  <div class="sec-title-seven">
                     <h2>Download Brochures</h2>
                  </div>
                  <ul class="files">
                     <li><a href="#"><span class="fa fa-file-pdf-o"></span> Download here .PDF</a></li>
                  </ul>
               </div>
               <!--quote-widget-->
               <div class="call-to-action-four" style="background-image:url(images/resource/quote-widget.jpg);">
                  <div class="title">Any Questions related Solutions? Call us</div>
                  <div class="number"><span class="flaticon-phone-receiver"></span> +44 7901 351369</div>
                  <a class="theme-btn btn-style-one" href="contact-us.php">GET QUOTES</a>
               </div>
            </aside>
         </div>
         <!--Sidebar-->
      </div>
   </div>
</div>
<?php include('footer.php');?>