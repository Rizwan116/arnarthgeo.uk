<div class="fix-icon">
   <div id="fix-icon" class="fix-icon-item">
      <a href="tel:+447901351369" target="blank"><img src="images/phone-icon.png" alt=""></a>
   </div>
</div>
<div class="fix-icon-whataap">
   <div id="fix-icon-whataap" class="fix-icon-whataap-item">
      <a href="https://api.whatsapp.com/send?phone=+447901351369&amp;text=Hi, I contacted you Through your website." target="blank"><img src="images/whatsapp.svg" alt=""></a>
   </div>
</div>
<style>
   /* CSS*/
   .fix-icon {
   display: inline-block;
   position: fixed;
   bottom: 100px;
   left: 20px;
   z-index: 999999;
   }
   #fix-icon {
   -webkit-animation-duration: 2.5s;
   animation-duration: 2.5s;
   -webkit-animation-fill-mode: both;
   animation-fill-mode: both;
   -webkit-animation-timing-function: linear;
   animation-timing-function: linear;
   animation-iteration-count: infinite;
   -webkit-animation-iteration-count: infinite;
   }
   .fix-icon-item {
   animation: bounce 1s infinite alternate;
   animation-duration: 1s;
   -webkit-animation: bounce 1s infinite alternate;
   animation-duration: 1s;
   animation-timing-function: ease;
   animation-iteration-count: infinite;
   animation-fill-mode: none;
   }
   .fix-icon-item img {
   width: 55px !important;
   height: 55px !important;
   background: 
   #1c999b;
   border-radius: 50%;
   text-align: center;
   cursor: pointer;
   padding: 10px;
   }
   .fix-icon-whataap {
   display: inline-block;
   position: fixed;
   bottom: 30px;
   left: 20px;
   z-index: 999999;
   transition: all0.5s ease-in-out;
   }
   .fix-icon-whataap-item img {
   border-radius: 50%;
   box-shadow: 1px 1px 4px 
   rgba(60, 60, 60, .4);
   transition: box-shadow .2s;
   cursor: pointer;
   overflow: hidden;
   width: 55px !important;
   height: 55px !important;
   background:
   #25d366 !important;
   }
   /*---*/
</style>
<!--Main Footer-->
<footer class="main-footer footer-style-two" style="background-image:url(images/background/footer-style-two.jpg);">
   <!--Footer Upper-->        
   <div class="footer-upper">
      <div class="auto-container">
         <div class="row clearfix">
            <div class="col-lg-5 col-sm-6 col-xs-12 column">
               <div class="footer-widget brighton-widget">
                  <div class="sec-title-three">
                     <h2>About ArnathGeo</h2>
                  </div>
                  <div class="text">ARNATHGEO UK Limited incepted with a vision to be a world leader in the geo textile
                     industry in 2018 with a world class manufacturing facility in the heart of textiles in India,
                     Ahmedabad. <a href="#">Read More</a>
                  </div>
                  <!--social-style-one-->
                  <ul class="social-style-one">
                     <li><a class="fa fa-linkedin" href="#"></a></li>
                  </ul>
               </div>
            </div>
            <div class="col-lg-3 col-sm-6 col-xs-12 column">
               <div class="sec-title-three">
                  <h2>Quick Links</h2>
               </div>
               <div class="footer-widget quick-links">
                  <div class="links-outer">
                     <div class="row clearfix">
                        <div class="col-md-6 col-sm-12 col-xs-12">
                           <ul>
                              <li><a href="#">Home</a></li>
                              <li><a href="#">About us</a></li>
                              <li><a href="#">Products</a></li>
                           </ul>
                        </div>
                        <div class="col-md-6 col-sm-12 col-xs-12">
                           <ul>
                              <li><a href="#">Infrastructure</a></li>
                              <li><a href="#">Quality Assurance</a></li>
                              <li><a href="#">Contact Us</a></li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-md-4 col-sm-12 col-xs-12">
               <div class="footer-widget">
                  <div class="sec-title-three">
                     <h2>Our Address</h2>
                  </div>
                  <ul class="contact-info">
                     <li><span class="icon flaticon-pin"></span><b>UK Office :-</b>128 City Road, London, EC1V 2NX.</li>
                     <!--<li><span class="icon flaticon-pin"></span><b>Corporate Office :-</b>28 City Road, London, EC1V 2NX</li>-->
                     <li><span class="icon flaticon-pin"></span><b>USA Office :-</b>728 Shadowood Parkway, Atlanta GA 30339</li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!--Footer Bottom-->
   <div class="footer-bottom">
      <div class="auto-container">
         <!--Copyright-->
         <div class="text-center">
            <div class="copyright">Copyrights &copy; 2025 Arnath Geo. All Rights Reserved.</div>
         </div>
      </div>
   </div>
</footer>
</div>
<!--End pagewrapper-->
<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>
<script type="text/javascript">
   function googleTranslateElementInit() {
     new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
   }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<script src="js/jquery.js"></script> 
<script src="js/bootstrap.min.js"></script>
<script src="js/revolution.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/isotope.js"></script>
<script src="js/script.js"></script>
</body>
</html>