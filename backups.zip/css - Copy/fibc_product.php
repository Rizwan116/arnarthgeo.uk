<?php include('header.php');?>
<section class="page-title" style="background-image:url(images/background/featured-2-bg.jpg);">
        <div class="auto-container">
            <h1>FIBC</h1>
        </div>
        
        <!--page-info-->
        <div class="page-info">
        	<div class="auto-container">
            	<div class="row clearfix">
            
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="bread-crumb clearfix">
                            <li><a href="index.php">Home</a></li>
                            <li class="active">FIBC</li>
                        </ul>
                    </div>
                    
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="social-nav clearfix">
                            <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                           
                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                           
                        </ul>
                    </div>
                
                </div>
            </div>
        </div>
        
    </section>

	<div class="sidebar-page-container">
        <div class="auto-container">
            <div class="row clearfix">
                 <div class="content-side col-lg-9 col-md-9 col-sm-12 col-xs-12">

                <!--Content Side-->
             
				<!--<div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">-->
                
    <!--                <section class="content-section services-content">-->
    <!--                	<figure class="bigger-image"><img src="images/photo 1.png" alt="" style=" width: 300px; "></figure>-->
				<!--		<div class="text center" style="text-align:center;"><a href="depot_bags.php" style="color:#000;font-weight: bold;">Depot Bag</a></div>-->

                       

                        
						
                
                        
    <!--                </section>-->

				<!--</div>-->
				<div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/builder-bag-1000x1000 (1).webp" alt="" style=" width: 300px; "></figure>
					

                       	<div class="text center" style="text-align:center;"><a href="builders_bag.php" style="color:#000;font-weight: bold;">Builder Bag</a></div>

                        
						
                
                        
                    </section>

				</div>
				
				  <div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/Tunnel.webp" alt=""></figure>
					

                       	<div class="text center" style="text-align:center;"><a href="Tunnel_Lift_Bulk_Bags.php" style="color:#000;font-weight: bold;">Tunnel Lift Bulk Bags</a></div>

                    </section>
                 </div>
				
				
				 <div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/BaffleBag.webp" alt=""></figure>
					

                       	<div class="text center" style="text-align:center;"><a href="baffle_bags.php" style="color:#000;font-weight: bold;">Baffle Bags</a></div>

                    </section>
                 </div>
				
				
                 
                 <div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/ScaffoldingBag.webp" alt=""></figure>
					

                       	<div class="text center" style="text-align:center;"><a href="Scaffolding_Bag.php" style="color:#000;font-weight: bold;">Scaffolding Bag</a></div>

                        
						
                
                        
                    </section>
                 </div>
                 
                
                 
                 <div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/VentilatedBag.webp" alt=""></figure>
					

                       	<div class="text center" style="text-align:center;"><a href="Ventilated_Bag.php" style="color:#000;font-weight: bold;">Ventilated Bag</a></div>

                    </section>
                 </div>
                 
                
                 
                 <div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/SkipBag.webp" alt=""></figure>
					

                       	<div class="text center" style="text-align:center;"><a href="Skip_Bag.php" style="color:#000;font-weight: bold;">Skip Bag</a></div>

                    </section>
                 </div>
                 
                 <!-- <div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">-->
                
                 <!--   <section class="content-section services-content">-->
                 <!--   	<figure class="bigger-image"><img src="images/photo 1.png" alt=""></figure>-->
					

                 <!--      	<div class="text center" style="text-align:center;"><a href="Seed_bulk_bag.php" style="color:#000;font-weight: bold;">Seed Bulk Bags</a></div>-->

                 <!--   </section>-->
                 <!--</div>-->
                 
                 
                 <!-- <div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">-->
                
                 <!--   <section class="content-section services-content">-->
                 <!--   	<figure class="bigger-image"><img src="images/photo 1.png" alt=""></figure>-->
					

                 <!--      	<div class="text center" style="text-align:center;"><a href="foodgrade_fibc.php" style="color:#000;font-weight: bold;">Foodgrade Fibc</a></div>-->

                 <!--   </section>-->
                 <!--</div>-->
                 
                 <div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/ventilated-jumbo-bag-1000x1000__1_ (1).webp" alt=""></figure>
					

                       	<div class="text center" style="text-align:center;"><a href="2-metre-tall_bulk_bags.php" style="color:#000;font-weight: bold;">2 Metre Tall Bulk Bags</a></div>

                    </section>
                 </div>
                 
                 	<div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/1-loop-fibc (1).webp" alt="" style=" width: 300px; "></figure>
					

                       	<div class="text center" style="text-align:center;"><a href="One_Two_Loop_Bag.php" style="color:#000;font-weight: bold;">One & Two Loop Bag</a></div>

                    </section>
                    
                    
                    
                 </div>
                 
                    <div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/photo 1.png" alt="" style=" width: 300px; "></figure>
                    	<div class="text center" style="text-align:center;"><a href="conduct_bag.php" style="color:#000;font-weight: bold;">Conduct Bag</a></div>
					
                    </section>

				</div>
				
				  <div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/spout-bottom-bulk-bag56094100087.jpeg" alt="" style=" width: 300px; "></figure>
                    	<div class="text center" style="text-align:center;"><a href="top-bottom-spout-bag.php" style="color:#000;font-weight: bold;">Top/Bottom Spout Bags</a></div>
					
                    </section>

				</div>
				
				  <div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/jumbo-bag-chennai-1000x100021.webp" alt="" style=" width: 300px; "></figure>
                    	<div class="text center" style="text-align:center;"><a href="top-flap-bag.php" style="color:#000;font-weight: bold;">Top Flap Bags</a></div>
					
                    </section>

				</div>
				
				  <div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/product-jpeg-1000x1000 (1).webp" alt="" style=" width: 300px; "></figure>
                    	<div class="text center" style="text-align:center;"><a href="top-skirt-bag.php" style="color:#000;font-weight: bold;">Top Skirt Bags</a></div>
					
                    </section>

				</div>
				
				<div class="content-side col-lg-3 col-md-4 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    	<figure class="bigger-image"><img src="images/liner.jpg" alt="" style=" width: 300px; "></figure>
                    	<div class="text center" style="text-align:center;"><a href="liner-bag.php" style="color:#000;font-weight: bold;"> Liner Bags</a></div>
					
                    </section>

				</div>
                 
                 
				</div>
                <!--Content Side-->

				<!--Sidebar-->
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <aside class="sidebar about-sidebar">

                        <!-- Tabbed Links -->
                        <div class="sidebar-widget tabbed-links">
                            <ul class="tabbed-nav">
                            	 <li><a href="geo-textiles.php">Builder Bag</a></li>
                                        <li><a href="erosion-control-section.php">Tunnel Lift Bulk Bags</a></li>
                                        <li><a href="agriculture-fabric.php">Baffle Bags</a></li>
                                        <li><a href="tarpulins.php">Scaffolding Bag</a></li>
                                        <li><a href="heavy-duty-tarpaulin.php">Ventilated Bag</a></li>
                                        
                                        <li><a href="industrial-fabric.php">Skip Bag</a></li>
                            </ul>

                        </div>

                        <!-- Tabbed Links -->
                        <div class="sidebar-widget download-links">
                            <div class="sec-title-seven"><h2>Download Brochures</h2></div>
                            <ul class="files">
                            	<li><a href="#"><span class="fa fa-file-pdf-o"></span> Download here .PDF</a></li>
                                 </ul>

                        </div>

						<!--quote-widget-->
						<div class="call-to-action-four" style="background-image:url(images/resource/quote-widget.jpg);">
                        	<div class="title">Any Questions related Solutions? Call us</div>
                            
                            <!--<div class="number"><span class="flaticon-phone-receiver"></span> +44 7901 351369</div>-->
                            <a class="theme-btn btn-style-one" href="contact-us.php">GET QUOTES</a>
                        </div>

                    </aside>


                </div>
                <!--Sidebar-->


            </div>
        </div>
    </div>
	


<?php include('footer.php');?>