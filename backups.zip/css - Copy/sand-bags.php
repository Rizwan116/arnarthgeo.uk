<?php include('header.php');?>
<section class="page-title" style="background-image:url(images/background/featured-2-bg.jpg);">
        <div class="auto-container">
            <h1>PP Woven Sack / Sand Bags</h1>
        </div>
        
        <!--page-info-->
        <div class="page-info">
        	<div class="auto-container">
            	<div class="row clearfix">
            
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="bread-crumb clearfix">
                            <li><a href="index.php">Home</a></li>
                            <li class="active">PP Woven Sack / Sand Bags</li>
                        </ul>
                    </div>
                    
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="social-nav clearfix">
                            <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                           
                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                           
                        </ul>
                    </div>
                
                </div>
            </div>
        </div>
        
    </section>
		<div class="sidebar-page-container">
        <div class="auto-container">
            <div class="row clearfix">

                <!--Content Side-->
                <div class="content-side col-lg-9 col-md-8 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    
                    	
                    	                    	<div id="imageSlider" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
        <li data-target="#imageSlider" data-slide-to="0" class="active"></li>
        <li data-target="#imageSlider" data-slide-to="1"></li>
         <li data-target="#imageSlider" data-slide-to="2"></li>
         
     
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
        <div class="item active">
            <img src="images/Bag 4.jpg" class="img-responsive center-block" alt="Slider Image 1" style="width: 350px;">
        </div>
        <div class="item">
            <img src="images/2.jpg" class="img-responsive center-block" alt="Slider Image 2" style="width: 350px;">
        </div>
         <div class="item">
            <img src="images/Bag 3.jpg" class="img-responsive center-block" alt="Slider Image 2" style="width: 350px;">
        </div>
        
        
    </div>

    <!-- Controls -->
    <a class="left carousel-control" href="#imageSlider" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
    </a>
    <a class="right carousel-control" href="#imageSlider" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
    </a>
</div>
						<div class="sec-title-one"><h2>PP Woven Sack / Sand Bags</h2></div>

                        <div class="text-block">
                        	<p>PP woven sand bags are made from polypropylene, a durable, thermoplastic material. They are used for flood control, construction, and military fortification. 
</p>
<p><h3>Features</h3>

&#183;  Strength: Made from durable, woven polypropylene that is tear resistant<br>
&#183;  Cost: Inexpensive compared to traditional materials<br>
&#183;  Weather resistance: Water and UV resistant<br>
&#183;  Recyclable: 100% recyclable<br>
&#183;  Versatile: Available in a range of sizes and colors<br>
&#183;  Customizable: Can be tailored to specific job requirements</p>
<p><h3>Uses</h3> 

&#183;  Flood control<br>
&#183;  Construction of levees, berms, dikes, and barricades<br>
&#183; Erosion control<br>
&#183; Flood walls<br>
&#183; Traffic control<br>
&#183; Military fortification<br>
&#183; Shielding glass windows in war zones<br>
&#183; Ballast</p>
<p><h3>Storage</h3> 
<br>
Store in a cool, dry area, preferably inside<br>
Used sand bags should be stored off the ground and out of direct sunlight</p>
<p>Other names Woven polypropylene sand bags, PP woven sand bags, and PP woven sacks. 
</p>							

						   </div>

                        
						
                
                        
                    </section>

				</div>
                <!--Content Side-->

				<!--Sidebar-->
                <div class="col-lg-3 col-md-4 col-sm-12 col-xs-12">
                    <aside class="sidebar about-sidebar">

                        <!-- Tabbed Links -->
                        <div class="sidebar-widget tabbed-links">
                            <ul class="tabbed-nav">
                            	 <li><a href="geo-textiles.php">Geo Textiles</a></li>
                                        <li><a href="erosion-control-section.php">Erosion Control Section</a></li>
                                        <li><a href="agriculture-fabric.php">Agriculture Fabric</a></li>
                                        <li><a href="tarpulins.php">Tarpaulins</a></li>
                                        <li><a href="heavy-duty-tarpaulin.php">Heavy Duty Tarpaulin</a></li>
                                        <li><a href="sand-bags.php">Sand Bags</a></li>
                                        <li><a href="industrial-fabric.php">Industrial Fabric</a></li>
                            </ul>

                        </div>

                        <!-- Tabbed Links -->
                        <div class="sidebar-widget download-links">
                            <div class="sec-title-seven"><h2>Download Brochures</h2></div>
                            <ul class="files">
                            	<li><a href="#"><span class="fa fa-file-pdf-o"></span> Download here .PDF</a></li>
                                 </ul>

                        </div>

						<!--quote-widget-->
						<div class="call-to-action-four" style="background-image:url(images/resource/quote-widget.jpg);">
                        	<div class="title">Any Questions related Solutions? Call us</div>
                            
                            <!--<div class="number"><span class="flaticon-phone-receiver"></span> +44 7901 351369</div>-->
                            <a class="theme-btn btn-style-one" href="contact-us.php">GET QUOTES</a>
                        </div>

                    </aside>


                </div>
                <!--Sidebar-->


            </div>
        </div>
    </div>
	
	
<?php include('footer.php');?>	