<?php include('header.php');?>
 <!--Main Slider-->
    <section class="main-slider">
    	
        <div class="tp-banner-container">
            <div class="tp-banner">
                <ul>
                	 <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="images/main-slider/1.jpg"  data-saveperformance="off"  data-title="Awesome Title Here">
                    <img src="images/slidera.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat"> 
                    
                    <!--Overlay-->
                    <div class="overlay-style-one"></div>
                    
                    <div class="tp-caption sfl sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="-110"
                    data-speed="1500"
                    data-start="0"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><div class="border-title"> ArnathGeo</div></div>
                    
                    <div class="tp-caption sfl sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="10"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><h2>Innovative Ideas, Redefining Strength</h2></div>
                    
                    <div class="tp-caption sfr sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="125"
                    data-speed="1500"
                    data-start="1000"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><a href="#" class="theme-btn btn-style-one">VIEW SOLUTIONS</a> &ensp;&ensp; <a href="#" class="theme-btn btn-style-two">CONTACT US</a></div>
                    
                    
                    </li>
                     <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="images/main-slider/1.jpg"  data-saveperformance="off"  data-title="Awesome Title Here">
                    <img src="images/sliderb.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat"> 
                    
                    <!--Overlay-->
                    <div class="overlay-style-one"></div>
                    
                    <div class="tp-caption sfl sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="-110"
                    data-speed="1500"
                    data-start="0"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><div class="border-title"> ArnathGeo</div></div>
                    
                    <div class="tp-caption sfl sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="10"
                    data-speed="1500"
                    data-start="500"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><h2>One Stop Solution For Woven PP Solutions</h2></div>
                    
                    <div class="tp-caption sfr sfb tp-resizeme"
                    data-x="left" data-hoffset="15"
                    data-y="center" data-voffset="125"
                    data-speed="1500"
                    data-start="1000"
                    data-easing="easeOutExpo"
                    data-splitin="none"
                    data-splitout="none"
                    data-elementdelay="0.01"
                    data-endelementdelay="0.3"
                    data-endspeed="1200"
                    data-endeasing="Power4.easeIn"><a href="#" class="theme-btn btn-style-one">VIEW SOLUTIONS</a> &ensp;&ensp; <a href="#" class="theme-btn btn-style-two">CONTACT US</a></div>
                    
                    
                    </li>
                    
                 
                    
                   
                 
                     
                </ul>
                
            	<div class="tp-bannertimer"></div>
            </div>
        </div>
    </section>
    
    <!--service-style-one-->
    <section class="service-style-one">
    	<div class="auto-container">
        	<div class="row clearfix">
            
            	<!--left-column-->
            	<div class="column left-column col-md-4 col-sm-12">
                	<!--box-column-->
                	<div class="box-column wow slideInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                    	<h2>Why We Choose us</h2>
                        <div class="text">We have the most advanced fully-automated state of the art Geo Textile manufacturing facility.</div>
                        <a class="more" href="#">VIEW MORE <span class="fa fa-long-arrow-right"></span></a>
                    </div>
                </div>
                
                <div class="col-md-8 col-sm-12">
                
                	<div class="row clearfix">
                    
                    	<!--service-block-->
                    	<div class="service-block col-md-6 col-sm-6 col-sm-12">
                        	<div class="inner-box">
                            	<!--icon-box-->
                            	<div class="icon-box">
                                	<span class="flaticon-atom"></span>
                                </div>
                                <h3>World Class Machine</h3>
                                <div class="text">We have the most advanced fully-automated state of the art Non-Woven Geo Textile manufacturing facility.</div>
                                
                            </div>
                        </div>
                        <!--service-block-->
                        <div class="service-block col-md-6 col-sm-6 col-sm-12">
                        	<div class="inner-box">
                            	<!--icon-box-->
                            	<div class="icon-box">
                                	<span class="flaticon-users"></span>
                                </div>
                                <h3>Top grade Geotextiles</h3>
                                <div class="text">Our Raw material comes from top Plastics processors like Exxon and Dow and many others which gives 
us edge in maintiaing the same consistency in the quality for our production.
</div>
                                
                            </div>
                        </div>
                        <!--service-block-->
                        <div class="service-block col-md-6 col-sm-6 col-sm-12">
                        	<div class="inner-box">
                            	<!--icon-box-->
                            	<div class="icon-box">
                                	<span class="flaticon-package-cube-box-for-delivery"></span>
                                </div>
                                <h3>Credibility</h3>
                                <div class="text">We have been supplying to all major infrastructure, and Geo synthetics companies in the world.</div>
                                
                            </div>
                        </div>
                        <!--service-block-->
                        <div class="service-block col-md-6 col-sm-6 col-sm-12">
                        	<div class="inner-box">
                            	<!--icon-box-->
                            	<div class="icon-box">
                                	<span class="flaticon-anchor"></span>
                                </div>
                                <h3>Quality Assurance</h3>
                                <div class="text">We prove 100% Assurance for all products.</div>
                                
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--call-to-action-->
    <section class="call-to-action" style="background-image:url(images/background/call-toaction-one-bg.png);">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<div class="col-md-8 col-sm-8 col-xs-12">
                	<h3>“ Innovation takes Practice for the Superior Level of Excellence ”</h3>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12 text-right">
                	<a class="quote-btn btn-style-three theme-btn" href="contact-us.php">Get a quote</a>
                </div>
            </div>
        </div>
    </section>
    
    <!--services-column-two-->
    <section class="services-column-two">
    	<div class="auto-container">
        	
            <!--Section Title-->
            <div class="sec-title-one">
            	<h2>Our Featured Products</h2>
                <div class="text"></div>
            </div>
			<div class="row clearfix">
            	
                <!--Service block two-->
                <div class="service-block-two col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                    	<div class="image-box">
                        	<figure class="image"><a href="#"><img src="images/geo-txt.jpg" alt=""></a></figure>
                        </div>
                        <div class="lower-content">
                        	<div class="outer-link">
                        		<a href="geo-textiles.php" class="theme-btn service-title"><span class="fa fa-long-arrow-right"></span>Geo Textiles</a>
                            </div>
                        	<div class="text">A geotextile is considered as any permeable textile material used to increase soil stability, provide erosion control or aid in drainage.</div>
                			<div class="link-box"><a href="geo-textiles.php" class="theme-btn normal-link">VIEW MORE <span class="fa fa-long-arrow-right"></span></a></div>
                        </div>
                    </div>
                </div>
                
                <div class="service-block-two col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                    	<div class="image-box">
                        	<figure class="image"><a href="#"><img src="images/resource/service-image-2.jpg" alt=""></a></figure>
                        </div>
                        <div class="lower-content">
                        	<div class="outer-link">
                        		<a href="erosion-control-section.php" class="theme-btn service-title"><span class="fa fa-long-arrow-right"></span>Erosion Control Section</a>
                            </div>
                        	<div class="text">Silt fences are temporary fabric used to retain sediment and control erosion on construction sites. Sediment such as sand, silt....</div>
                			<div class="link-box"><a href="erosion-control-section.php" class="theme-btn normal-link">VIEW MORE <span class="fa fa-long-arrow-right"></span></a></div>
                        </div>
                    </div>
                </div>
                
                <div class="service-block-two col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                    	<div class="image-box">
                        	<figure class="image"><a href="agriculture-fabric.php"><img src="images/resource/service-image-3.jpg" alt=""></a></figure>
                        </div>
                        <div class="lower-content">
                        	<div class="outer-link">
                        		<a href="#" class="theme-btn service-title"><span class="fa fa-long-arrow-right"></span> Agriculture Fabric</a>
                            </div>
                        	<div class="text">They are designed to stop grasses and weeds safely in gardens,fields, greenhouses and display areas by eliminating virtually all light.</div>
                			<div class="link-box"><a href="agriculture-fabric.php" class="theme-btn normal-link">VIEW MORE <span class="fa fa-long-arrow-right"></span></a></div>
                        </div>
                    </div>
                </div>
                
                <div class="service-block-two col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                    	<div class="image-box">
                        	<figure class="image"><a href="#"><img src="images/resource/service-image-4.jpg" alt=""></a></figure>
                        </div>
                        <div class="lower-content">
                        	<div class="outer-link">
                        		<a href="tarpulins.php" class="theme-btn service-title"><span class="fa fa-long-arrow-right"></span> Tarpaulins</a>
                            </div>
                        	<div class="text">A tarpaulin or tarp is a large sheet of waterproof cloth. Tarps are used for temporary shelter and to cover items being stored outdoors.</div>
                			<div class="link-box"><a href="tarpulins.php" class="theme-btn normal-link">VIEW MORE <span class="fa fa-long-arrow-right"></span></a></div>
                        </div>
                    </div>
                </div>
                
                <div class="service-block-two col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                    	<div class="image-box">
                        	<figure class="image"><a href="#"><img src="images/resource/service-image-5.jpg" alt=""></a></figure>
                        </div>
                        <div class="lower-content">
                        	<div class="outer-link">
                        		<a href="industrial-fabric.php" class="theme-btn service-title"><span class="fa fa-long-arrow-right"></span>Industrial Fabric</a>
                            </div>
                        	<div class="text">These are made from a variety of fibers and blends, using resin bonds and treatments to offer desired roofing membrane characteristics ...</div>
                			<div class="link-box"><a href="industrial-fabric.php" class="theme-btn normal-link">VIEW MORE <span class="fa fa-long-arrow-right"></span></a></div>
                        </div>
                    </div>
                </div>
                
                <div class="service-block-two col-md-4 col-sm-6 col-xs-12">
                	<div class="inner-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                    	<div class="image-box">
                        	<figure class="image"><a href="sand-bags.php"><img src="images/resource/service-image-6.jpg" alt=""></a></figure>
                        </div>
                        <div class="lower-content">
                        	<div class="outer-link">
                        		<a href="sand-bags.php" class="theme-btn service-title"><span class="fa fa-long-arrow-right"></span>Sand Bags </a>
                            </div>
                        	<div class="text">Our woven polypropylene sand bag comes complete with heavy twine ties. They are available in white (1600 hr. UV protection).</div>
                			<div class="link-box"><a href="sand-bags.php" class="theme-btn normal-link">VIEW MORE <span class="fa fa-long-arrow-right"></span></a></div>
                        </div>
                    </div>
                </div>
                
            </div>
            
            
        </div>
    </section>
    
   
    
    <!--Default Section-->
    <section class="default-section">
    	<div class="auto-container">
            <div class="row clearfix">
            	
                <!--Text Column-->
                <div class="column text-column col-md-6 col-sm-12 col-xs-12">
                	<div class="inner-box">
                    
                    	<div class="sec-title-one">
                            <h2>About us</h2>
                        </div>
                        
                    	<div class="text">ARNATH GEOTEXTILE incepted with a vision to be a world leader in the geo textile
industry in 2018 with a world class manufacturing facility in the heart of textiles in India,
Ahmedabad. 
<br>
We are high quality manufacturer and supplier of  Geosynthetic products  which holds a good
market presence. In a very short span of time ARNATH emerged as a leading brand in
geotextile segment across the globe.

<a href="#">Read More</a></div>
                        
                        <!--featured-gallery-->
                        <div class="featured-gallery">
                            <div class="row clearfix">
                            
                            	<!--featured-image-box-->
                                <div class="featured-image-box col-md-12 col-sm-12 col-xs-12">
                                	<figure class="image">
                                    	<a class="lightbox-image" href="images/resource/featured-image-1.jpg" title="Image Caption Here"><img src="images/resource/featured-image-1.jpg" alt="" /></a>
                                    </figure>
                                </div>
                                
                              
                                
                            </div>
                        </div>
                        
                    </div>
                </div>
                
                <!--Accordions Column-->
                <div class="column col-md-6 col-sm-12 col-xs-12">
                	<div class="inner-box">
                    
                    	<div class="sec-title-one">
                            <h2>Frequently Asked Questions</h2>
                        </div>
                    
                    	<!--Accordion Box-->
                        <ul class="accordion-box">
                            
                            <!--Block-->
                            <li class="accordion block wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                <div class="acc-btn active"><div class="icon-outer"><span class="icon icon-plus fa fa-plus"></span> <span class="icon icon-minus fa fa-minus"></span></div>What is Woven Fabric?</div>
                                <div class="acc-content current">
                                    <div class="content clearfix">
                                       
                                        <p>It is a type of fabric obtained from weaving of pp tapes into warps (vertical stands) and wefts
(horizontal stands).</p>
                                    </div>
                                </div>
                            </li>
                            
                            <!--Block-->
                            <li class="accordion block wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
                                <div class="acc-btn"><div class="icon-outer"><span class="icon icon-plus fa fa-plus"></span> <span class="icon icon-minus fa fa-minus"></span></div>Does The Label Match The Product Inside?</div>
                                <div class="acc-content">
                                    <div class="content clearfix">

                                        <p>Insist the fabric itself is branded and not just the wrapping. It is easy for suppliers to wrap non-
descript imported rolls and label them as something else. This passes risk to you. To avoid this
you can source products from suppliers who not only provide detailed roll labeling (including
traceable individual rolls numbers) but who also mark the geotextile fabric directly.</p>
                                    </div>
                                </div>
                            </li>
                            
                            <!--Block-->
                            <li class="accordion block wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
                                <div class="acc-btn"><div class="icon-outer"><span class="icon icon-plus fa fa-plus"></span> <span class="icon icon-minus fa fa-minus"></span></div>Can You Match My Exact Requirements?</div>
                                <div class="acc-content">
                                    <div class="content clearfix">
                                     
                                        <p>Geotextiles are often defined in a consultant’s specification. Suppliers who simply distribute
can’t influence the nature of the products they sell. Hence they try and make your specification
fit their geotextile, rather than the other way round. Again this carries risk for you. Arnath
provide R&amp;D, technical support and in challenging cases, bespoke products tailored to your
needs.</p>
                                    </div>
                                </div>
                            </li>
                            
                                <li class="accordion block wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
                                <div class="acc-btn"><div class="icon-outer"><span class="icon icon-plus fa fa-plus"></span> <span class="icon icon-minus fa fa-minus"></span></div>Can You Support Me To Deliver The Project?</div>
                                <div class="acc-content">
                                    <div class="content clearfix">
                                     
                                        <p>Geosynthetics are technical in nature. Good suppliers go beyond simple supply and assist you in
liaising with all the project stakeholders including specifies, auditors, contractors and asset
owners. They should provide a site presence and a detailed solution above the physical product.
All with the aim of a timely, cost effective and safe project conclusion for you the customer.</p>
                                    </div>
                                </div>
                            </li>
                            
                                <li class="accordion block wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
                                <div class="acc-btn"><div class="icon-outer"><span class="icon icon-plus fa fa-plus"></span> <span class="icon icon-minus fa fa-minus"></span></div>Is The Product Readily Available?</div>
                                <div class="acc-content">
                                    <div class="content clearfix">
                                     
                                        <p>Geotextiles usually get installed in the early stages of a project. If they are held up, this can have
severe knock on effects to larger components of the job. In these lean times suppliers are inclined
to over promise to win your order. Geotextiles are also bulky, so insist you source from suppliers
with large local capacity, reputation and financial stability to hold stock and satisfy your needs
promptly.</p>
                                    </div>
                                </div>
                            </li>
                            
                         
                            
                        </ul><!--End Accordion Box-->
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    
    <!--testimonial-section-->
    <section class="testimonial-section">
    	<div class="auto-container">
        	<div class="row clearfix">
            	<!--testimonial-column-->
            	<div class="testimonial-column col-md-8 col-sm-12 col-xs-12">
                	<div class="sec-title-one">
                    	<h2>What People Says</h2>
                    </div>
                    
                    <!--Carousel Outer-->
                    <div class="carousel-outer">
                        <div class="single-item-carousel">
        
                            <!--testimonial box-->
                            <div class="testimonial-box">
                                <div class="text"><span class="fa fa-quote-left"></span>Arnath maintains consistent good quality for small as well as large order volumes.<span class="fa fa-quote-right"></span></div>
                                <!--author-info-->
                                <div class="author-info">
                                	<figure class="image">
                                    	<img src="images/resource/author-thumb-1.jpg" alt="" />
                                    </figure>
                                    <h3>George Mc Mahon</h3>
                                    <div class="designation">Co-Founder</div>
                                    
                                </div>
                            </div>
                            
                            <div class="testimonial-box">
                                <div class="text"><span class="fa fa-quote-left"></span>Arnath's infrastructure is intelligently planned, with good organized departments, well maintained hygiene, more safety, less burden on the environment, more efficient provision of public goods and services, better jobs.<span class="fa fa-quote-right"></span></div>
                                <div class="author-info">
                                	<figure class="image">
                                    	<img src="images/resource/author-thumb-1.jpg" alt="" />
                                    </figure>
                                    <h3>George Mc Mahon</h3>
                                    <div class="designation">Co-Founder</div>
                                    
                                </div>
                            </div>
                            
						</div>
					</div>
                    
                </div>
                
                <div class="fact-counter-column col-md-4 col-sm-12 col-xs-12">
                	<div class="fact-counter">
                <div class="clearfix">
                
                    <!--Column-->
                    <div class="column counter-column wow fadeIn" data-wow-duration="0ms">
                    	<div class="inner">
                        	<div class="count-outer">
                            	<span class="icon-box"><span class="fa fa-star-o"></span></span>
                            	<span class="count-text" data-speed="1500" data-stop="4">0</span>
                            </div>
                            <h4 class="counter-title">Years of Excellence</h4>
                       	</div>
                    </div>
                    
                    <!--Column-->
                    <div class="column counter-column wow fadeIn" data-wow-duration="0ms">
                    	<div class="inner">
                        	<div class="count-outer">
                            	<span class="icon-box"><span class="flaticon-museum"></span></span>
                            	<span class="count-text" data-speed="1500" data-stop="2">0</span>
                            </div>
                            <h4 class="counter-title">Global Branches</h4>
                       	</div>
                    </div>
                    
                    <!--Column-->
                    <div class="column counter-column wow fadeIn" data-wow-duration="0ms">
                    	<div class="inner">
                        	<div class="count-outer">
                            	<span class="icon-box"><span class="flaticon-medal"></span></span>
                            	<span class="count-text" data-speed="1500" data-stop="20">0</span>
                            </div>
                            <h4 class="counter-title">Promoted Awards</h4>
                       	</div>
                    </div>
                    
                </div>
            </div>
                </div>
                
            </div>
        </div>
    </section>
    
   
<?php include('footer.php');?>	