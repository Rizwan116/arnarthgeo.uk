<?php include('header.php');?>
<section class="page-title" style="background-image:url(images/background/featured-2-bg.jpg);">
        <div class="auto-container">
            <h1>Industrial Fabric</h1>
        </div>
        
        <!--page-info-->
        <div class="page-info">
        	<div class="auto-container">
            	<div class="row clearfix">
            
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="bread-crumb clearfix">
                            <li><a href="index.php">Home</a></li>
                            <li class="active">Industrial Fabric</li>
                        </ul>
                    </div>
                    
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="social-nav clearfix">
                            <li><a href="#"><span class="fa fa-facebook-f"></span></a></li>
                            <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                           
                            <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                           
                        </ul>
                    </div>
                
                </div>
            </div>
        </div>
        
    </section>
	
	<div class="sidebar-page-container">
        <div class="auto-container">
            <div class="row clearfix">

                <!--Content Side-->
                <div class="content-side col-lg-9 col-md-8 col-sm-12 col-xs-12">
                
                    <section class="content-section services-content">
                    
						<div class="sec-title-one"><h2>Industrial Fabric</h2></div>

                        <div class="text-block">
 <p><b>LUMBER WRAP :-</b></p>
                        	<p>1) Weight : 95-130gsm<br>
2) Structure :PP woven grid +pp film<br>
3) Width : Within 320cm<br>
4) Color : White /Black /Tan<br>
5) Application : Used for lumber and other wood products<br>
6) UV resistant<br>
7) Priint color is available<br>
8) Fabric 5 x5 mesh, 1-4 color printing and 126&quot; in width
</p>
<p><img src="images/lumber.png" /></p>
<p><b>Roofing fabric :-</b></p>
<p>
    These are made from a variety of fibers and blends, using resin bonds and treatments to offer desired roofing membrane characteristics such as breathability and water resistance. 
</p>
<p>Our fabrics are with formulation and manufacturing capabilities provide fabrics that are custom suited to specific roofing membrane application requirements. we can manufacture in a variety of colors, textures, and thicknesses, providing the widest selection of options for roofing membrane products. Treatments include:
</p>
<p>
    •	Anti-microbial/anti-bacterial<br>
•	Anti-static<br>
•	Biodegradable<br>
•	Colors custom matched<br>
•	Flame Retardant<br>
•	Heat Sealability<br>
•	Printing<br>
•	And more

</p>
<p><img src="images/roofing.png" /></p>
<p>
    <b>HOUSE WRAP FABRICS :-</b>
</p>
<p>
    House wrap technically is a type of water-resistive barrier or WRB. The purpose of using house wrap is to prevent the entry of moisture into the wall cavity from outside. If a house wrap is impermeable, it can trap this indoor moisture in the wall cavity, potentially leading to rot and mold growth. 
</p>
<p>
    House wrap is intended to be installed over the sheathing and behind the siding, no matter what siding you are using: wood, fiber cement, vinyl, brick, stucco, and others. Siding manufacturers may recommend specific types of fabrics to use with their products.
</p>
<p><img src="images/house.png" /></p>
<p>
    <b>Some of the features of the house wraps :</b><br>
    •	Strong, durable UV protected<br>
•	Air resistance<br>
•	Moisture vapor transmission<br>
•	Eco friendly recyclable

</p>
	</div>

                        
						
                
                        
                    </section>

				</div>
                <!--Content Side-->

				<!--Sidebar-->
                <div class="col-lg-3 col-md-4 col-sm-12 col-xs-12">
                    <aside class="sidebar about-sidebar">

                        <!-- Tabbed Links -->
                        <div class="sidebar-widget tabbed-links">
                            <ul class="tabbed-nav">
                            	 <li><a href="geo-textiles.php">Geo Textiles</a></li>
                                        <li><a href="erosion-control-section.php">Erosion Control Section</a></li>
                                        <li><a href="agriculture-fabric.php">Agriculture Fabric</a></li>
                                        <li><a href="tarpulins.php">Tarpaulins</a></li>
                                        <li><a href="heavy-duty-tarpaulin.php">Heavy Duty Tarpaulin</a></li>
                                        <li><a href="sand-bags.php">Sand Bags</a></li>
                                        <li><a href="industrial-fabric.php">Industrial Fabric</a></li>
                            </ul>

                        </div>

                        <!-- Tabbed Links -->
                        <div class="sidebar-widget download-links">
                            <div class="sec-title-seven"><h2>Download Brochures</h2></div>
                            <ul class="files">
                            	<li><a href="#"><span class="fa fa-file-pdf-o"></span> Download here .PDF</a></li>
                                 </ul>

                        </div>

						<!--quote-widget-->
						<div class="call-to-action-four" style="background-image:url(images/resource/quote-widget.jpg);">
                        	<div class="title">Any Questions related Solutions? Call us</div>
                            
                            <!--<div class="number"><span class="flaticon-phone-receiver"></span> +44 7901 351369</div>-->
                            <a class="theme-btn btn-style-one" href="contact-us.php">GET QUOTES</a>
                        </div>

                    </aside>


                </div>
                <!--Sidebar-->


            </div>
        </div>
    </div>
	
	
<?php include('footer.php');?>	